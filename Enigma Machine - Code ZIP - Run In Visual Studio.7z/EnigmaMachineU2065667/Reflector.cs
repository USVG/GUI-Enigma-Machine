﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enigma
{
    class Reflector
    {
        Char[] reflectorArray;
        int reflectorType;

        public Reflector()
        {

        }

        public void setReflector(char reflectorType)
        {
            
            if (reflectorType == 'B')
            {
                Char[] temp = { 'Y','R','U','H','Q','S','L','D','P','X','N','G','O','K','M','I','E','B','F','Z','C','W','V','J','A','T' };
                reflectorArray = temp;
                this.reflectorType = 1;

            } else if (reflectorType == 'C') 
            {
                Char[] temp = { 'F','V','P','J','I','A','O','Y','E','D','R','Z','X','W','G','C','T','K','U','Q','S','B','N','M','H','L' };
                reflectorArray = temp;
                this.reflectorType = 2;
            } else
            {
                //ERROR
            }

        }

        public int getReflectorType()
        {
            return reflectorType;
        }

        public Char substitute(Char input)
        {
            switch (input)
            {
                case 'A':
                    return reflectorArray[0];
                case 'B':
                    return reflectorArray[1];
                case 'C':
                    return reflectorArray[2];
                case 'D':
                    return reflectorArray[3];
                case 'E':
                    return reflectorArray[4];
                case 'F':
                    return reflectorArray[5];
                case 'G':
                    return reflectorArray[6];
                case 'H':
                    return reflectorArray[7];
                case 'I':
                    return reflectorArray[8];
                case 'J':
                    return reflectorArray[9];
                case 'K':
                    return reflectorArray[10];
                case 'L':
                    return reflectorArray[11];
                case 'M':
                    return reflectorArray[12];
                case 'N':
                    return reflectorArray[13];
                case 'O':
                    return reflectorArray[14];
                case 'P':
                    return reflectorArray[15];
                case 'Q':
                    return reflectorArray[16];
                case 'R':
                    return reflectorArray[17];
                case 'S':
                    return reflectorArray[18];
                case 'T':
                    return reflectorArray[19];
                case 'U':
                    return reflectorArray[20];
                case 'V':
                    return reflectorArray[21];
                case 'W':
                    return reflectorArray[22];
                case 'X':
                    return reflectorArray[23];
                case 'Y':
                    return reflectorArray[24];
                case 'Z':
                    return reflectorArray[25];
            }
            return 'X';
        }
    }
}