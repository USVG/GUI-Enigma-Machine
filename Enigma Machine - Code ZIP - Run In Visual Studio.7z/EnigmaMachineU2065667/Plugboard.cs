﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enigma
{
    class Plugboard
    {
        private List<string> map;
        public Plugboard()
        {
            map = new List<string>();
        }

        public Char substitute(char a)
        {
            foreach (string s in map)
            {
                char[] c = s.ToCharArray();
                if (c.Contains(a))
                {
                    if (c[0] == a) { return c[1]; }
                    else if (c[1] == a) { return c[0]; }
                }
            }
            return a;
        }

        public void addMapping(char a, char b)
        {
            map.Add(a + "" + b);
        }

        public void clearMap()
        {
            map.Clear();
        }
    }
}