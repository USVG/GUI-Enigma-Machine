﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enigma
{
    class Rotor
    {
        Char[] alphabet = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        Char[] array;
        int offset = 0;
        int rotorNumber;

        public Rotor()
        {
        }

        public Char substitute(Char input)
        {
            for (int i = 0; i < 26; i++)
            {

                if (alphabet[i] == input)
                {
                    int arrayIndex = i + offset;
                    arrayIndex = arrayIndex % 26;
                    
                    return array[arrayIndex];
                }
            }
            Environment.Exit(0);
            return 'x';
        }

        public Char substituteNoRotate(Char input)
        {
            for (int i = 0; i < 26; i++)
            {

                if (array[i] == input)
                {
                    int arrayIndex = i - offset;
                    arrayIndex = arrayIndex + 26;
                    arrayIndex = arrayIndex % 26;

                    return alphabet[arrayIndex];
                }
            }
            return 'x';
        }

        public void setRotor(int rotorNumber)
        {
            switch (rotorNumber)
            {
                case 1:
                    Char[] temp = { 'E','K','M','F','L','G','D','Q','V','Z','N','T','O','W','Y','H','X','U','S','P','A','I','B','R','C','J' };
                    array = temp;
                    this.rotorNumber = rotorNumber;
                    break;

                case 2:
                    Char[] temp2 = { 'A','J','D','K','S','I','R','U','X','B','L','H','W','T','M','C','Q','G','Z','N','P','Y','F','V','O','E' };
                    array = temp2;
                    this.rotorNumber = rotorNumber;
                    break;

                case 3:
                    Char[] temp3 = { 'B','D','F','H','J','L','C','P','R','T','X','V','Z','N','Y','E','I','W','G','A','K','M','U','S','Q','O' };
                    array = temp3;
                    this.rotorNumber = rotorNumber;
                    break;
                case 4:
                    Char[] temp4 = { 'E','S','O','V','P','Z','J','A','Y','Q','U','I','R','H','X','L','N','F','T','G','K','D','C','M','W','B' };
                    array = temp4;
                    this.rotorNumber = rotorNumber;
                    break;
                case 5:
                    Char[] temp5 = { 'V','Z','B','R','G','I','T','Y','U','P','S','D','N','H','L','X','A','W','M','J','Q','O','F','E','C','K' };
                    array = temp5;
                    this.rotorNumber = rotorNumber;
                    break;
            }
        }

        public void updateRotorPos()
        {
            //update position by 1 until it gets to 25 (use 25 as starting from 0), and then set back to 0
            setOffset((getOffset() + 1) % 25);
        }

        public void incrementOffset()
        {
            offset = offset + 1;
        }

        public int getOffset()
        {
            return offset;
        }

        public void setOffset(int newOffset)
        {
            this.offset = newOffset;
        }

        public int getRotorNumber()
        {
            return rotorNumber;
        }

    }
}
