﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enigma
{
    class Enigma
    {
       // Plugboard plugBoard;
       // Rotor fast;
        //Rotor middle;
        //Rotor slow;
        Plugboard plugBoard = new Plugboard();
        Rotor fast = new Rotor();
        Rotor middle = new Rotor();
        Rotor slow = new Rotor();
        Reflector reflector = new Reflector();

        public Enigma()
        {
            

        }

        public void setRotorsOffsets(string rotorName, int rotorOffset)
        {
            if (rotorName == "fast")
            {
                fast.setOffset(rotorOffset);
            }

            if (rotorName == "middle")
            {
                middle.setOffset(rotorOffset);
            }

            if (rotorName == "slow")
            {
                slow.setOffset(rotorOffset);
            }
        }

        public void setRotor(string rotorName ,int rotorType)
        {
            if (rotorName == "fast")
            {
                fast.setRotor(rotorType);
            }

            if (rotorName == "middle")
            {
                middle.setRotor(rotorType);
            }

            if (rotorName == "slow")
            {
                slow.setRotor(rotorType);
            }
        }

        public void setReflector(char reflectorType)
        {
            reflector.setReflector(reflectorType);
        }
        public int getReflector()
        {
            return reflector.getReflectorType();
        }

        public int getRotorsNumbers(String rotor)
        {
            switch (rotor)
            {
                case "fast":
                    return fast.getRotorNumber();
                case "middle":
                    return middle.getRotorNumber();
                case "slow":
                    return slow.getRotorNumber();
            }
            return -1;
        }
        public int getRotorsOffsets(String rotor)
        {
            switch (rotor)
            {
                case "fast":
                    return fast.getOffset();
                case "middle":
                    return middle.getOffset();
                case "slow":
                    return slow.getOffset();
            }
            return -1;
        }
        
        public string encryptString(string plaintext)
        {
            char[] plain = plaintext.ToCharArray();
            char[] cipher = new char[plain.Length];

            for (int i = 0; i < plain.Length; i++)
            {
                char p = plain[i];
                p = forward(p);   
                cipher[i] = reverse(p);
                //update positions
                updatePositions();
            }

            return new string(cipher);
        }

        public void updatePositions()
        {
            fast.updateRotorPos();
            if (fast.getOffset() == 0)
            {
                middle.updateRotorPos();
                if (middle.getOffset() == 0)
                {
                    slow.updateRotorPos();
                }
            }

        }

        public char forward(char p)
        {
            //plugboard
            p = plugBoard.substitute(p);
            //fast rotor
            p = fast.substitute(p);
            //middle rotor
            p = middle.substitute(p);
            //slow rotor
            p = slow.substitute(p);
            //reflector
            p = reflector.substitute(p);
            return p;
        }

        public char reverse(char p)
        {

            //fast rotor
            p = slow.substituteNoRotate(p);
            //middle rotor
            p = middle.substituteNoRotate(p);
            //slow rotor
            p = fast.substituteNoRotate(p);
            //plugboard
            p = plugBoard.substitute(p);
            return p;
        }

        public void addMapPlugboard(string a, string b)
        {
            char c1 = a.ToCharArray()[0];  
            char c2 = b.ToCharArray()[0];
            plugBoard.addMapping(c1, c2);
        }

        public void clearPlugboard()
        {
            plugBoard.clearMap();
        }

    }
}
