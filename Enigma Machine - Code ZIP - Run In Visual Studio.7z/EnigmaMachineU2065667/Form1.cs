namespace EnigmaMachineU2065667
{
    public partial class EnigmaWindow : Form
    {
        Enigma.Enigma enigma = new Enigma.Enigma();
        
        public EnigmaWindow()
        {
            enigma.setRotor("fast", 1);
            enigma.setRotor("middle", 2);
            enigma.setRotor("slow", 3);
            enigma.setReflector('B');
            InitializeComponent();
            Load += new EventHandler(Form1_Load);
        }

        private void Form1_Load(object sender, System.EventArgs e)
        {
            initialiseFields();


            cbxConfigureSetup.Checked = false;

        }

        public void initialiseFields()
        {
            cmbFastOffsetSelect.SelectedIndex = enigma.getRotorsOffsets("fast");

            cmbMidOffsetSelect.SelectedIndex = enigma.getRotorsOffsets("middle");
            
            cmbSlowOffsetSelect.SelectedIndex = enigma.getRotorsOffsets("slow");

            cmbFastRotorSelect.SelectedIndex = enigma.getRotorsNumbers("fast") - 1;

            cmbMidRotorSelect.SelectedIndex = enigma.getRotorsNumbers("middle")-1;

            cmbSlowRotorSelect.SelectedIndex = enigma.getRotorsNumbers("slow") - 1;

            cmbReflectorSelect.SelectedIndex = enigma.getReflector()-1;

        }

        public void updateFields()
        {
            cmbFastOffsetSelect.SelectedIndex = enigma.getRotorsOffsets("fast");

            cmbMidOffsetSelect.SelectedIndex = enigma.getRotorsOffsets("middle");

            cmbSlowOffsetSelect.SelectedIndex = enigma.getRotorsOffsets("slow");
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(txbPlaintext.Text, "^[a-zA-Z ]"))
            {
                MessageBox.Show("Cannot convert plaintext\n\nPlease ensure the plaintext only contains letters and is not empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                String p = txbPlaintext.Text;
                String c = enigma.encryptString(p.Trim().Replace(" ", "").ToUpper());
                txbCiphertext.Text = c;
                updateFields();
            }
            
        }

        public Boolean rotorCheck(string rotor1, string rotor2, int rotorNumber)
        {
            if ((enigma.getRotorsNumbers(rotor1) == rotorNumber) || (enigma.getRotorsNumbers(rotor2) == rotorNumber))
            {
                MessageBox.Show("Another rotor is already using this rotor wheel\n\nPlease select another rotor wheel", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            } else
            {
                return true;
            }
        }

        private void cmbFastRotorSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFastRotorSelect.SelectedIndex == 0)
            {
                if (rotorCheck("middle", "slow", 1)){
                    enigma.setRotor("fast", 1);
                } 
            }
            if (cmbFastRotorSelect.SelectedIndex == 1)
            {
                if (rotorCheck("middle", "slow", 2))
                {
                    enigma.setRotor("fast", 2);
                }
            }
            if (cmbFastRotorSelect.SelectedIndex == 2)
            {
                if (rotorCheck("middle", "slow", 3))
                {
                    enigma.setRotor("fast", 3);
                }
            }
            if (cmbFastRotorSelect.SelectedIndex == 3)
            {
                if (rotorCheck("middle", "slow", 4))
                {
                    enigma.setRotor("fast", 4);
                }
            }
            if (cmbFastRotorSelect.SelectedIndex == 4)
            {
                if (rotorCheck("middle", "slow", 5))
                {
                    enigma.setRotor("fast", 5);
                }
            }
            int b = enigma.getRotorsNumbers("fast");
            cmbFastRotorSelect.SelectedIndex = b - 1;
        }

        private void cmbMidRotorSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMidRotorSelect.SelectedIndex == 0)
            {
                if (rotorCheck("fast", "slow", 1))
                {
                    enigma.setRotor("middle", 1);
                }
            }
            if (cmbMidRotorSelect.SelectedIndex == 1)
            {
                if (rotorCheck("fast", "slow", 2))
                {
                    enigma.setRotor("middle", 2);
                }
            }
            if (cmbMidRotorSelect.SelectedIndex == 2)
            {
                if (rotorCheck("fast", "slow", 3))
                {
                    enigma.setRotor("middle", 3);
                }
            }
            if (cmbMidRotorSelect.SelectedIndex == 3)
            {
                if (rotorCheck("fast", "slow", 4))
                {
                    enigma.setRotor("middle", 4);
                }
            }
            if (cmbMidRotorSelect.SelectedIndex == 4)
            {
                if (rotorCheck("fast", "slow", 5))
                {
                    enigma.setRotor("middle", 5);
                }
            }
            int b = enigma.getRotorsNumbers("middle");
            cmbMidRotorSelect.SelectedIndex = b - 1;
        }

        private void cmbSlowRotorSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSlowRotorSelect.SelectedIndex == 0)
            {
                if (rotorCheck("fast", "middle", 1))
                {
                    enigma.setRotor("slow", 1);
                }
            }
            if (cmbSlowRotorSelect.SelectedIndex == 1)
            {
                if (rotorCheck("fast", "middle", 2))
                {
                    enigma.setRotor("slow", 2);
                }
            }
            if (cmbSlowRotorSelect.SelectedIndex == 2)
            {
                if (rotorCheck("fast", "middle", 3))
                {
                    enigma.setRotor("slow", 3);
                }
            }
            if (cmbSlowRotorSelect.SelectedIndex == 3)
            {
                if (rotorCheck("fast", "middle", 4))
                {
                    enigma.setRotor("slow", 4);
                }
            }
            if (cmbSlowRotorSelect.SelectedIndex == 4)
            {
                if (rotorCheck("fast", "middle", 5))
                {
                    enigma.setRotor("slow", 5);
                }
            }
            int b = enigma.getRotorsNumbers("slow");
            cmbSlowRotorSelect.SelectedIndex = b - 1;
        }

        private void cmbReflectorSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbReflectorSelect.SelectedIndex == 0)
            {
                enigma.setReflector('B');
            }
            if (cmbReflectorSelect.SelectedIndex == 1)
            {
                enigma.setReflector('C');
            }
        }

        private void cmbFastOffsetSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cmbFastOffsetSelect.SelectedIndex == 0)
            {
                enigma.setRotorsOffsets("fast", 0);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 1)
            {
                enigma.setRotorsOffsets("fast", 1);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 2)
            {
                enigma.setRotorsOffsets("fast", 2);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 3)
            {
                enigma.setRotorsOffsets("fast", 3);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 4)
            {
                enigma.setRotorsOffsets("fast", 4);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 5)
            {
                enigma.setRotorsOffsets("fast", 5);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 6)
            {
                enigma.setRotorsOffsets("fast", 6);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 7)
            {
                enigma.setRotorsOffsets("fast", 7);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 8)
            {
                enigma.setRotorsOffsets("fast", 8);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 9)
            {
                enigma.setRotorsOffsets("fast", 9);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 10)
            {
                enigma.setRotorsOffsets("fast", 10);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 11)
            {
                enigma.setRotorsOffsets("fast", 11);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 12)
            {
                enigma.setRotorsOffsets("fast", 12);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 13)
            {
                enigma.setRotorsOffsets("fast", 13);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 14)
            {
                enigma.setRotorsOffsets("fast", 14);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 15)
            {
                enigma.setRotorsOffsets("fast", 15);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 16)
            {
                enigma.setRotorsOffsets("fast", 16);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 17)
            {
                enigma.setRotorsOffsets("fast", 17);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 18)
            {
                enigma.setRotorsOffsets("fast", 18);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 19)
            {
                enigma.setRotorsOffsets("fast", 19);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 20)
            {
                enigma.setRotorsOffsets("fast", 20);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 21)
            {
                enigma.setRotorsOffsets("fast", 21);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 22)
            {
                enigma.setRotorsOffsets("fast", 22);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 23)
            {
                enigma.setRotorsOffsets("fast", 23);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 24)
            {
                enigma.setRotorsOffsets("fast", 24);
            }
            if (cmbFastOffsetSelect.SelectedIndex == 25)
            {
                enigma.setRotorsOffsets("fast", 25);
            }
        }

        private void cmbMidOffsetSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMidOffsetSelect.SelectedIndex == 0)
            {
                enigma.setRotorsOffsets("middle", 0);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 1)
            {
                enigma.setRotorsOffsets("middle", 1);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 2)
            {
                enigma.setRotorsOffsets("middle", 2);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 3)
            {
                enigma.setRotorsOffsets("middle", 3);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 4)
            {
                enigma.setRotorsOffsets("middle", 4);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 5)
            {
                enigma.setRotorsOffsets("middle", 5);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 6)
            {
                enigma.setRotorsOffsets("middle", 6);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 7)
            {
                enigma.setRotorsOffsets("middle", 7);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 8)
            {
                enigma.setRotorsOffsets("middle", 8);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 9)
            {
                enigma.setRotorsOffsets("middle", 9);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 10)
            {
                enigma.setRotorsOffsets("middle", 10);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 11)
            {
                enigma.setRotorsOffsets("middle", 11);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 12)
            {
                enigma.setRotorsOffsets("middle", 12);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 13)
            {
                enigma.setRotorsOffsets("middle", 13);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 14)
            {
                enigma.setRotorsOffsets("middle", 14);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 15)
            {
                enigma.setRotorsOffsets("middle", 15);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 16)
            {
                enigma.setRotorsOffsets("middle", 16);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 17)
            {
                enigma.setRotorsOffsets("middle", 17);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 18)
            {
                enigma.setRotorsOffsets("middle", 18);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 19)
            {
                enigma.setRotorsOffsets("middle", 19);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 20)
            {
                enigma.setRotorsOffsets("middle", 20);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 21)
            {
                enigma.setRotorsOffsets("middle", 21);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 22)
            {
                enigma.setRotorsOffsets("middle", 22);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 23)
            {
                enigma.setRotorsOffsets("middle", 23);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 24)
            {
                enigma.setRotorsOffsets("middle", 24);
            }
            if (cmbMidOffsetSelect.SelectedIndex == 25)
            {
                enigma.setRotorsOffsets("middle", 25);
            }
        }

        private void cmbSlowOffsetSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSlowOffsetSelect.SelectedIndex == 0)
            {
                enigma.setRotorsOffsets("slow", 0);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 1)
            {
                enigma.setRotorsOffsets("slow", 1);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 2)
            {
                enigma.setRotorsOffsets("slow", 2);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 3)
            {
                enigma.setRotorsOffsets("slow", 3);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 4)
            {
                enigma.setRotorsOffsets("slow", 4);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 5)
            {
                enigma.setRotorsOffsets("slow", 5);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 6)
            {
                enigma.setRotorsOffsets("slow", 6);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 7)
            {
                enigma.setRotorsOffsets("slow", 7);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 8)
            {
                enigma.setRotorsOffsets("slow", 8);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 9)
            {
                enigma.setRotorsOffsets("slow", 9);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 10)
            {
                enigma.setRotorsOffsets("slow", 10);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 11)
            {
                enigma.setRotorsOffsets("slow", 11);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 12)
            {
                enigma.setRotorsOffsets("slow", 12);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 13)
            {
                enigma.setRotorsOffsets("slow", 13);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 14)
            {
                enigma.setRotorsOffsets("slow", 14);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 15)
            {
                enigma.setRotorsOffsets("slow", 15);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 16)
            {
                enigma.setRotorsOffsets("slow", 16);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 17)
            {
                enigma.setRotorsOffsets("slow", 17);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 18)
            {
                enigma.setRotorsOffsets("slow", 18);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 19)
            {
                enigma.setRotorsOffsets("slow", 19);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 20)
            {
                enigma.setRotorsOffsets("slow", 20);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 21)
            {
                enigma.setRotorsOffsets("slow", 21);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 22)
            {
                enigma.setRotorsOffsets("slow", 22);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 23)
            {
                enigma.setRotorsOffsets("slow", 23);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 24)
            {
                enigma.setRotorsOffsets("slow", 24);
            }
            if (cmbSlowOffsetSelect.SelectedIndex == 25)
            {
                enigma.setRotorsOffsets("slow", 25);
            }
        }
        private void cbxConfigureSetup_CheckedChanged(object sender, EventArgs e)
        {
            if (cbxConfigureSetup.Checked == true)
            {
                cbxConfigureSetup.Text = "Stop Configuring";
                btnConvert.Enabled = false;
                txbPlaintext.Enabled = false;
                txbCiphertext.Enabled = false;

                
                cmbFastOffsetSelect.Enabled = true;
                cmbMidOffsetSelect.Enabled = true;
                cmbSlowOffsetSelect.Enabled = true;
                cmbFastRotorSelect.Enabled = true;
                cmbMidRotorSelect.Enabled = true;
                cmbSlowRotorSelect.Enabled = true;
                cmbReflectorSelect.Enabled = true;
                
            }
            if (cbxConfigureSetup.Checked == false)
            {
                cbxConfigureSetup.Text = "Configure Setup";
                btnConvert.Enabled = true;
                txbPlaintext.Enabled = true;
                txbCiphertext.Enabled = true;

                
                cmbFastOffsetSelect.Enabled = false;
                cmbMidOffsetSelect.Enabled = false;
                cmbSlowOffsetSelect.Enabled=false;
                cmbFastRotorSelect.Enabled = false;
                cmbMidRotorSelect.Enabled = false;
                cmbSlowRotorSelect.Enabled = false;
                cmbReflectorSelect.Enabled = false;
                
            }
        }

        private void btnPlugboardAdd_Click(object sender, EventArgs e)
        {
            if ((!System.Text.RegularExpressions.Regex.IsMatch(txbPlugboardInput.Text, "^[a-zA-Z ]")) || (!System.Text.RegularExpressions.Regex.IsMatch(txbPlugboardInput.Text, "^[a-zA-Z ]"))) {
                MessageBox.Show("Invalid plugboard input \n\nPlease ensure you are only entering letters", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                string a = txbPlugboardInput.Text.ToUpper();
                string b = txbPlugboardOutput.Text.ToUpper();
                enigma.addMapPlugboard(a, b);
                txbPlugboardSetup.AppendText("(" + a + ", " + b + ")");
                txbPlugboardInput.Text = "";
                txbPlugboardOutput.Text = "";
            }
            

        }

        private void btnClearPlugboard_Click(object sender, EventArgs e)
        {
            enigma.clearPlugboard();
            txbPlugboardSetup.Clear();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("By Umur Sajid", "Enigma Machine", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}